From mak@bu.edu Tue Feb 24 10:25:11 2009
Date: Mon, 23 Feb 2009 12:20:21 -0500
From: Mark Kramer <mak@bu.edu>
To: Eric Kolaczyk <kolaczyk@math.bu.edu>
Subject: Book data

Hi Eric,

	I've created a folder on the math server with the data.  Check out,

	/tmp/for_eric/

	Inside you will find 16 ASCII files.  For each seizure (8 total)  
there are two files, one pre-ictal (labeled 'pre') and the other  
ictal (labeled 'ict').  Each file is 4000 X 76 (i.e., 4000 time  
points by 76 electrodes).  The sampling rate is 400 Hz, so each file  
contains 10 s of data recorded at the 76 electrodes.

	Anyone interested in more details about the data can check out our  
paper.

	Let me know if this works.

	   Mark
